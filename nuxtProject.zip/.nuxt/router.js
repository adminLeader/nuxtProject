import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _46213488 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _2cd1edbd = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _6da4124b = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _6e0f7c0b = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _35bfd3fe = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _54d9bf58 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))
const _3a525acb = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _46213488,
    children: [{
      path: "",
      component: _2cd1edbd,
      name: "index"
    }, {
      path: "/login",
      component: _6da4124b,
      name: "login"
    }, {
      path: "/register",
      component: _6da4124b,
      name: "register"
    }, {
      path: "/profile/:usernanme",
      component: _6e0f7c0b,
      name: "userProfile"
    }, {
      path: "/settings",
      component: _35bfd3fe,
      name: "settingIndex"
    }, {
      path: "/article/:slug",
      component: _54d9bf58,
      name: "articleIndex"
    }, {
      path: "/editor",
      component: _3a525acb,
      name: "editor"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
