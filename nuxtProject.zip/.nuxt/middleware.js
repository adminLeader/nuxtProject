const middleware = {}

middleware['userState'] = require('..\\middleware\\userState.js')
middleware['userState'] = middleware['userState'].default || middleware['userState']

export default middleware
